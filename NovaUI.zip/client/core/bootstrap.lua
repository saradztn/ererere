--[[
    NovaUI - Resource Bootstrap, Exports & Memory Cleanup Lifecycle
    File: client/core/bootstrap.lua
]]

NovaUI = NovaUI or {}

function NovaUI.shutdown()
    -- 1. Destroy all components
    NovaUI.destroyAll()

    -- 2. Kill all tracked timers
    if NovaUI._registry and NovaUI._registry.timers then
        for timer in pairs(NovaUI._registry.timers) do
            NovaUI.killTimer(timer)
        end
        NovaUI._registry.timers = {}
    end

    -- 3. Unload cached textures & SVGs
    if NovaUI.Assets and NovaUI.Assets.unloadAll then
        NovaUI.Assets.unloadAll()
    end

    -- 4. Unload cached fonts
    if NovaUI.Fonts and NovaUI.Fonts.unloadAll then
        NovaUI.Fonts.unloadAll()
    end

    -- 5. Clean up DGS Adapter caches
    if NovaUI.DGSAdapter and NovaUI.DGSAdapter.cleanup then
        NovaUI.DGSAdapter.cleanup()
    end

    -- 6. Restore input mode
    if type(guiSetInputMode) == "function" then
        pcall(guiSetInputMode, "allow_binds")
    end
end

-- Exported global functions for cross-resource MTA:SA usage
function novaCreate(typeName, props, parentId)
    local parent = parentId and NovaUI.getElementById(parentId) or nil
    local comp = NovaUI.create(typeName, props, parent)
    return comp and comp.id or false
end

function novaDestroy(elementOrId)
    local comp = type(elementOrId) == "table" and elementOrId or NovaUI.getElementById(elementOrId)
    if comp and type(comp.destroy) == "function" then
        return comp:destroy()
    end
    return false
end

function novaSetTheme(themeName)
    return NovaUI.setTheme(themeName)
end

function novaCreateTheme(name, definition, baseTheme)
    return NovaUI.createTheme(name, definition, baseTheme) ~= nil
end

function novaScale(val)
    return NovaUI.scale(val)
end

function novaNotify(options)
    local n = NovaUI.notify(options)
    return n and n.id or false
end

function novaConfirm(options)
    local m = NovaUI.confirm(options)
    return m and m.id or false
end

function novaSetVisible(elementId, visible)
    local comp = NovaUI.getElementById(elementId)
    if comp then
        comp:setVisible(visible)
        return true
    end
    return false
end

---Resolve an id (or pass through an already resolved component).
local function novaResolve(elementOrId)
    if type(elementOrId) == "table" and elementOrId._isComponent then return elementOrId end
    if elementOrId == nil then return nil end
    return NovaUI.getElementById(elementOrId)
end

---Attach an event listener to a component created from another resource.
---NovaUI auto-binds the onClick/onChange/onHover/onFocus/onBlur/onClose/onSubmit
---props, but events such as "select", "sort", "doubleClick" or "minimize" can
---only be subscribed to after the component exists - which is what this is for.
function novaOn(elementOrId, eventName, handler)
    local comp = novaResolve(elementOrId)
    if comp and type(eventName) == "string" and type(handler) == "function"
        and type(comp.on) == "function" then
        comp:on(eventName, handler)
        return true
    end
    return false
end

function novaOnce(elementOrId, eventName, handler)
    local comp = novaResolve(elementOrId)
    if comp and type(eventName) == "string" and type(handler) == "function"
        and type(comp.once) == "function" then
        comp:once(eventName, handler)
        return true
    end
    return false
end

function novaOff(elementOrId, eventName, handler)
    local comp = novaResolve(elementOrId)
    if comp and type(eventName) == "string" and type(comp.off) == "function" then
        comp:off(eventName, handler)
        return true
    end
    return false
end

---Batch update a component's properties (same as comp:update(props)).
function novaUpdate(elementOrId, newProps)
    local comp = novaResolve(elementOrId)
    if comp and type(newProps) == "table" and type(comp.update) == "function" then
        comp:update(newProps)
        return true
    end
    return false
end

---Call any method on a component: novaCall(id, "setRows", rows).
---Returns only a boolean so no component table (and its function valued props)
---ever crosses the resource boundary.
function novaCall(elementOrId, methodName, ...)
    local comp = novaResolve(elementOrId)
    if not comp or type(methodName) ~= "string" then return false end
    local fn = comp[methodName]
    if type(fn) ~= "function" then return false end
    local ok = pcall(fn, comp, ...)
    return ok
end

---Run an animation spec on a component.
function novaAnimate(elementOrId, spec)
    local comp = novaResolve(elementOrId)
    if not comp or type(spec) ~= "table" then return false end
    NovaUI.animate(comp, spec)
    return true
end

---Read a component's current value (edit, slider, switch, dropdown, ...).
function novaGetValue(elementOrId)
    local comp = novaResolve(elementOrId)
    if comp and type(comp.getValue) == "function" then
        return comp:getValue()
    end
    return nil
end

function novaSetText(elementOrId, text)
    local comp = novaResolve(elementOrId)
    if comp and type(comp.setText) == "function" then
        comp:setText(text)
        return true
    end
    return false
end

if type(addEventHandler) == "function" and type(resourceRoot) ~= "nil" then
    addEventHandler("onClientResourceStop", resourceRoot, function()
        NovaUI.shutdown()
    end)
end
